const fileInput = document.querySelector("#reference-input");
const preview = document.querySelector("#preview");
const form = document.querySelector("#post-form");
const loading = document.querySelector("#loading");

if (fileInput && preview) {
  fileInput.addEventListener("change", () => {
    const file = fileInput.files?.[0];
    if (!file) {
      preview.hidden = true;
      preview.removeAttribute("src");
      return;
    }
    preview.src = URL.createObjectURL(file);
    preview.hidden = false;
  });
}
