const runId = document.body.dataset.runId;
const rail = document.querySelector("#agent-rail");
const logList = document.querySelector("#live-log");
const statusText = document.querySelector("#live-status");
const captionEl = document.querySelector("#live-caption");
const mediaEl = document.querySelector("#live-media");
const resultLink = document.querySelector("#result-link");

const statusLabels = {
  waiting: "Waiting",
  active: "Working",
  done: "Done",
  skipped: "Skipped",
  error: "Error",
};

let lastLogCount = 0;

async function pollRun() {
  const response = await fetch(`/api/run/${runId}`);
  const data = await response.json();
  renderAgents(data.agents || []);
  renderLogs(data.logs || []);
  renderOutput(data);

  statusText.textContent = statusMessage(data);

  if (data.result_url) {
    resultLink.href = data.result_url;
    resultLink.hidden = false;
  }

  if (data.status === "finished" || data.status === "error") {
    return;
  }

  window.setTimeout(pollRun, 850);
}

function renderAgents(agents) {
  for (const agent of agents) {
    const node = rail.querySelector(`[data-agent="${agent.key}"]`);
    if (!node) continue;
    node.className = `agent-node ${agent.status}`;
    node.querySelector("strong").textContent = statusLabels[agent.status] || agent.status;
    node.querySelector("small").textContent = agent.message || agent.description;
  }
}

function renderLogs(logs) {
  if (logs.length === lastLogCount) return;
  lastLogCount = logs.length;
  logList.innerHTML = logs.map((log) => `
    <li class="${escapeHtml(log.status)}">
      <strong>${escapeHtml(log.step)}</strong>
      <span>${escapeHtml(log.status)}</span>
      <p>${escapeHtml(log.message)}</p>
    </li>
  `).join("");
  logList.scrollTop = logList.scrollHeight;
}

function renderOutput(data) {
  if (data.caption) {
    captionEl.textContent = data.caption;
    captionEl.classList.remove("muted");
  }

  if (data.media_url) {
    mediaEl.className = "live-media";
    mediaEl.innerHTML = `<img src="${data.media_url}" alt="Generated media">`;
  }
}

function statusMessage(data) {
  if (data.status === "queued") return "Queued. Waiting for Task Manager.";
  if (data.status === "error") return `Stopped with error: ${data.error || "unknown error"}`;
  if (data.status === "finished") return "Finished. Final post is ready for review.";

  const active = (data.agents || []).find((agent) => agent.status === "active");
  if (!active) return "Agents are synchronizing...";
  return `${active.label} is working: ${active.message}`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

pollRun();
