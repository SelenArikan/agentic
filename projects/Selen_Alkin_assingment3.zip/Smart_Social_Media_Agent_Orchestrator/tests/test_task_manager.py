import sys
import tempfile
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agents import TaskManagerAgent
from models import PostState


class TaskManagerTests(unittest.TestCase):
    def test_post_this_requires_topic_clarification(self):
        with tempfile.TemporaryDirectory() as tmp:
            manager = TaskManagerAgent(output_dir=tmp)
            state = manager.run(PostState(user_prompt="Post this."), ask_user=None)

            self.assertTrue(state.needs_clarification)
            self.assertEqual(state.pending_clarification, "topic")
            self.assertIn("topic", state.clarification_question.lower())

    def test_short_prompt_full_route_with_demo_defaults(self):
        answers = iter(["local demo", "fitness-focused"])

        with tempfile.TemporaryDirectory() as tmp:
            manager = TaskManagerAgent(output_dir=tmp)
            state = manager.run(
                PostState(user_prompt="Make a post about Pilates."),
                ask_user=lambda _question: next(answers),
            )

            self.assertEqual(state.routing_plan["researcher"], True)
            self.assertEqual(state.routing_plan["writer"], True)
            self.assertEqual(state.routing_plan["media_creator"], True)
            self.assertEqual(state.routing_plan["browser"], True)
            self.assertEqual(state.qa_status, "approved")
            self.assertEqual(state.browser_status, "success")
            self.assertTrue(Path(state.media_path).exists())

    def test_exact_text_skips_research_and_writer(self):
        with tempfile.TemporaryDirectory() as tmp:
            manager = TaskManagerAgent(output_dir=tmp)
            state = manager.run(
                PostState(user_prompt="Share this exact text: 'Join my class!' with a picture of a reformer bed."),
                ask_user=lambda _question: "local demo",
            )

            self.assertFalse(state.routing_plan["researcher"])
            self.assertFalse(state.routing_plan["writer"])
            self.assertTrue(state.routing_plan["media_creator"])
            self.assertEqual(state.caption, "Join my class!")
            self.assertEqual(state.qa_status, "approved")


if __name__ == "__main__":
    unittest.main()
