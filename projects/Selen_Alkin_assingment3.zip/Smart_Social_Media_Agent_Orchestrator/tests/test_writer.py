import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agents.writer import ContentWriterAgent
from models import PostState


class WriterTests(unittest.TestCase):
    def test_writer_does_not_overwrite_existing_caption(self):
        state = PostState(
            user_prompt="Share this exact text: 'Join my class!'",
            topic="Pilates",
            caption="Join my class!",
            routing_plan={"media_creator": True},
            hashtags=["#pilates"],
        )

        ContentWriterAgent().write_content(state)

        self.assertEqual(state.caption, "Join my class!")
        self.assertIsNotNone(state.media_prompt)


if __name__ == "__main__":
    unittest.main()
