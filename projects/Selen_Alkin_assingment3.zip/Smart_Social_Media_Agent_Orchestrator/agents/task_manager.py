from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Callable, Optional

from config import (
    MAX_CLARIFICATION_QUESTIONS,
    MVP_DEMO_ONLY,
    NVIDIA_BASE_URL,
    NVIDIA_IMAGE_BASE_URL,
    NVIDIA_IMAGE_CANDIDATES,
    NVIDIA_IMAGE_ENDPOINT,
    NVIDIA_IMAGE_MODEL,
    NVIDIA_MODEL,
    NVIDIA_QA_MODEL,
    NVIDIA_RESEARCH_MODEL,
    NVIDIA_WRITER_MODEL,
    OUTPUT_DIR,
)
from models import PostState
from providers import NvidiaBuildClient

from .browser_operator import BrowserOperatorAgent
from .media_creator import MediaCreatorAgent
from .qa_agent import QAAgent
from .researcher import TrendResearcherAgent
from .writer import ContentWriterAgent


AskUser = Callable[[str], str]


class TaskManagerAgent:
    """Central orchestrator for routing, validation, retry, and logs."""

    REAL_PLATFORMS = {"instagram", "tiktok", "facebook", "linkedin", "x", "twitter"}
    LOCAL_PLATFORMS = {"local", "local demo", "local_demo", "demo"}
    MEDIA_WORDS = {"picture", "image", "photo", "visual", "video", "reel", "media"}
    UPLOAD_WORDS = {"upload", "share", "publish"}

    def __init__(
        self,
        *,
        provider: str = "mock",
        output_dir: Path | str = OUTPUT_DIR,
        use_playwright: bool = False,
        max_clarifications: int = MAX_CLARIFICATION_QUESTIONS,
    ) -> None:
        self.provider = provider
        self.output_dir = Path(output_dir)
        self.use_playwright = use_playwright
        self.max_clarifications = max_clarifications

        strict_api = provider == "nvidia"
        research_client = NvidiaBuildClient(model=NVIDIA_RESEARCH_MODEL) if provider == "nvidia" else None
        writer_client = NvidiaBuildClient(model=NVIDIA_WRITER_MODEL) if provider == "nvidia" else None
        image_client = NvidiaBuildClient(model=NVIDIA_WRITER_MODEL) if provider == "nvidia" else None
        qa_client = NvidiaBuildClient(model=NVIDIA_QA_MODEL) if provider == "nvidia" else None
        self.researcher = TrendResearcherAgent(research_client, strict_api=strict_api)
        self.writer = ContentWriterAgent(writer_client, strict_api=strict_api)
        self.media_creator = MediaCreatorAgent(image_client, strict_api=strict_api)
        self.qa_agent = QAAgent(qa_client, strict_api=strict_api)
        self.browser = BrowserOperatorAgent()

    def run(self, state: PostState, ask_user: Optional[AskUser] = None) -> PostState:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._clean_previous_media_outputs()
        state.add_log(
            "task_manager",
            "start",
            "Workflow started.",
            provider=self.provider,
            nvidia_default_chat_model=NVIDIA_MODEL if self.provider == "nvidia" else None,
            nvidia_research_model=NVIDIA_RESEARCH_MODEL if self.provider == "nvidia" else None,
            nvidia_writer_model=NVIDIA_WRITER_MODEL if self.provider == "nvidia" else None,
            nvidia_qa_model=NVIDIA_QA_MODEL if self.provider == "nvidia" else None,
            nvidia_chat_endpoint=f"{NVIDIA_BASE_URL.rstrip('/')}/chat/completions" if self.provider == "nvidia" else None,
            nvidia_image_endpoint=(
                NVIDIA_IMAGE_ENDPOINT or f"{NVIDIA_IMAGE_BASE_URL.rstrip('/')}/{NVIDIA_IMAGE_MODEL}"
                if self.provider == "nvidia"
                else None
            ),
            nvidia_image_candidates=NVIDIA_IMAGE_CANDIDATES if self.provider == "nvidia" else None,
        )

        while True:
            self.analyze_prompt(state)
            if not state.needs_clarification:
                break

            state.add_log("task_manager", "clarification_needed", state.clarification_question or "")
            if ask_user is None:
                self._save_outputs(state)
                return state

            if state.clarification_count >= self.max_clarifications:
                state.can_continue = False
                state.add_log("task_manager", "blocked", "Maximum clarification question limit reached.")
                self._save_outputs(state)
                return state

            answer = ask_user(state.clarification_question or "Please clarify the request.")
            self.merge_clarification(state, answer)

        if not state.can_continue:
            self._save_outputs(state)
            return state

        self._execute_route(state)
        self._save_outputs(state)
        return state

    def analyze_prompt(self, state: PostState) -> PostState:
        prompt = self._combined_prompt(state)
        lower = prompt.lower()

        state.needs_clarification = False
        state.clarification_question = None
        state.pending_clarification = None
        state.can_continue = True

        self._extract_existing_media_path(state, prompt)
        if not state.caption:
            state.caption = self._extract_caption(prompt)
        if not state.media_prompt:
            state.media_prompt = self._extract_media_prompt(prompt)
        if not state.topic:
            state.topic = self._extract_topic(prompt, state)
        if not state.platform:
            state.platform = self._extract_platform(lower)

        exact_text_requested = "exact text" in lower or "use this exact text" in lower
        if exact_text_requested and not state.caption:
            return self._ask(state, "exact_text", "Please provide the exact text you want me to use.")

        if self._is_empty_post_request(lower, state):
            return self._ask(state, "topic", "What content or topic should I post?")

        caption_only = self._is_caption_only_request(lower)
        needs_upload = self._needs_upload(lower)
        needs_media = self._needs_media(lower, needs_upload, caption_only, state)
        needs_research = self._needs_research(prompt, state)
        needs_writer = not bool(state.caption)

        if needs_upload and not state.platform:
            return self._ask(
                state,
                "platform",
                "Which platform should I post to? Instagram, TikTok, LinkedIn, X, or local demo?",
            )

        if MVP_DEMO_ONLY and needs_upload and state.platform in self.REAL_PLATFORMS:
            return self._ask(
                state,
                "demo_confirm",
                "This prototype supports local demo upload only. Should I continue with the demo upload page?",
            )

        if needs_upload and "upload this" in lower and not state.caption and not state.has_media_file and not state.topic:
            return self._ask(state, "caption_or_media", "Do you want me to create the caption, the image, or both?")

        if needs_media and not state.visual_style and not state.media_prompt:
            return self._ask(
                state,
                "visual_style",
                "What visual style do you prefer? Minimal, realistic, colorful, luxury, or fitness-focused?",
            )

        if needs_media and not state.media_prompt:
            state.media_prompt = f"{state.visual_style or 'clean'} image about {state.topic or 'the requested topic'}"

        state.routing_plan = {
            "researcher": needs_research,
            "writer": needs_writer,
            "media_creator": needs_media and not state.has_media_file,
            "qa": True,
            "browser": needs_upload,
        }
        state.add_log("task_manager", "success", "Routing plan created.", routing_plan=state.routing_plan)
        return state

    def merge_clarification(self, state: PostState, answer: str) -> PostState:
        cleaned = answer.strip()
        state.clarification_answer = cleaned
        state.clarification_count += 1
        state.clarification_history.append(
            {
                "question": state.clarification_question or "",
                "answer": cleaned,
                "field": state.pending_clarification or "unknown",
            }
        )

        field = state.pending_clarification
        if field == "platform":
            state.platform = self._normalize_platform(cleaned)
        elif field == "demo_confirm":
            if cleaned.lower() in {"yes", "y", "ok", "continue", "sure", "evet"}:
                state.platform = "local_demo"
            else:
                state.can_continue = False
        elif field == "exact_text":
            state.caption = cleaned.strip("\"'")
        elif field == "topic":
            state.topic = cleaned
        elif field == "visual_style":
            state.visual_style = cleaned
        elif field == "caption_or_media":
            if "caption" in cleaned.lower() or "both" in cleaned.lower():
                state.caption = None
            if "image" in cleaned.lower() or "media" in cleaned.lower() or "both" in cleaned.lower():
                state.media_prompt = state.media_prompt or f"local demo image about {state.topic or 'the request'}"
        else:
            state.topic = state.topic or cleaned

        state.add_log("task_manager", "clarification_received", "Clarification merged.", field=field)
        return state

    def _execute_route(self, state: PostState) -> PostState:
        if state.routing_plan.get("researcher"):
            self._run_with_retry(state, "researcher", self.researcher.get_trends, self._validate_research)
        else:
            state.add_log("researcher", "skipped", "Research skipped by routing plan.")

        if state.routing_plan.get("writer"):
            self._run_with_retry(state, "writer", self.writer.write_content, self._validate_writer)
        else:
            state.add_log("writer", "skipped", "Writer skipped because caption is already available.")

        if state.routing_plan.get("media_creator"):
            action = lambda current: self.media_creator.create_media(current, self.output_dir)
            self._run_with_retry(state, "media_creator", action, self._validate_media)
        elif state.has_media_file:
            state.add_log("media_creator", "skipped", "Media creator skipped because media file already exists.")
        else:
            state.add_log("media_creator", "skipped", "Media creator skipped by routing plan.")

        self._run_with_retry(state, "qa", self.qa_agent.review, self._validate_qa)

        if state.qa_status != "approved":
            state.can_continue = False
            state.add_log("task_manager", "blocked", "QA rejected the post; browser step skipped.")
            return state

        if state.routing_plan.get("browser"):
            action = lambda current: self.browser.upload_to_demo(
                current,
                self.output_dir,
                use_playwright=self.use_playwright,
            )
            self._run_with_retry(state, "browser", action, self._validate_browser)
        else:
            state.add_log("browser", "skipped", "Browser upload skipped by routing plan.")

        state.add_log("task_manager", "success", "Workflow finished.")
        return state

    def _run_with_retry(self, state: PostState, name: str, action, validator) -> None:
        for attempt in range(1, 3):
            before_errors = len(state.errors)
            try:
                action(state)
            except Exception as exc:
                state.errors.append(f"{name} failed on attempt {attempt}: {exc}")
                state.add_log(name, "error", str(exc), attempt=attempt)

            valid, message = validator(state)
            if valid:
                state.add_log("task_manager", "validated", f"{name} output validated.", attempt=attempt)
                return

            if len(state.errors) == before_errors:
                state.errors.append(f"{name} validation failed on attempt {attempt}: {message}")
            state.add_log("task_manager", "retry" if attempt == 1 else "failed", message, agent=name, attempt=attempt)

        state.can_continue = False

    def _validate_research(self, state: PostState) -> tuple[bool, str]:
        if len(state.keywords) >= 3 and len(state.hashtags) >= 2:
            return True, "Research output is valid."
        return False, "Researcher must return at least 3 keywords and 2 hashtags."

    def _validate_writer(self, state: PostState) -> tuple[bool, str]:
        if not state.caption:
            return False, "Writer must return a caption."
        if state.routing_plan.get("media_creator") and not state.media_prompt:
            return False, "Writer must return a media prompt when media is needed."
        return True, "Writer output is valid."

    def _validate_media(self, state: PostState) -> tuple[bool, str]:
        if not state.media_path:
            return False, "Media creator did not return media_path."
        if not Path(state.media_path).exists():
            return False, f"Media path does not exist: {state.media_path}"
        return True, "Media output is valid."

    def _validate_qa(self, state: PostState) -> tuple[bool, str]:
        if state.qa_status in {"approved", "rejected"}:
            return True, "QA output is valid."
        return False, "QA must return approved or rejected."

    def _validate_browser(self, state: PostState) -> tuple[bool, str]:
        if state.browser_status == "success":
            return True, "Browser upload is valid."
        return False, state.browser_feedback or "Browser upload failed."

    def _save_outputs(self, state: PostState) -> None:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        (self.output_dir / "logs.json").write_text(json.dumps(state.logs, indent=2), encoding="utf-8")
        (self.output_dir / "state.json").write_text(json.dumps(state.to_dict(), indent=2), encoding="utf-8")

    def _clean_previous_media_outputs(self) -> None:
        for name in (
            "generated_post.jpg",
            "generated_post.nvidia_response.json",
            "generated_post.prompt.json",
            "browser_upload_manifest.json",
        ):
            path = self.output_dir / name
            if path.exists():
                path.unlink()

    def _ask(self, state: PostState, field: str, question: str) -> PostState:
        state.needs_clarification = True
        state.clarification_question = question
        state.pending_clarification = field
        state.can_continue = False
        return state

    def _combined_prompt(self, state: PostState) -> str:
        parts = [state.user_prompt]
        parts.extend(item["answer"] for item in state.clarification_history if item.get("field") == "topic")
        return " ".join(part for part in parts if part).strip()

    def _extract_caption(self, prompt: str) -> Optional[str]:
        patterns = [
            r"(?:exact text|caption|post text|text)\s*:\s*['\"]([^'\"]{2,2200})['\"]",
            r"(?:use|share|post)\s+this\s+exact\s+text\s*['\"]([^'\"]{2,2200})['\"]",
        ]
        for pattern in patterns:
            match = re.search(pattern, prompt, flags=re.IGNORECASE)
            if match:
                return match.group(1).strip()
        return None

    def _extract_media_prompt(self, prompt: str) -> Optional[str]:
        match = re.search(
            r"(?:picture|image|photo|visual|video|reel)\s+(?:of|showing|with)\s+(.+?)(?:\.|,|$)",
            prompt,
            flags=re.IGNORECASE,
        )
        if match:
            return match.group(1).strip()
        return None

    def _extract_topic(self, prompt: str, state: PostState) -> Optional[str]:
        for pattern in (
            r"\babout\s+(.+?)(?:\s+with\b|\.|,|$)",
            r"\bfor\s+(?:a|an)?\s*(.+?)\s+post\b",
        ):
            match = re.search(pattern, prompt, flags=re.IGNORECASE)
            if match:
                topic = self._clean_topic(match.group(1))
                if topic:
                    return topic

        if state.media_prompt:
            return self._clean_topic(state.media_prompt)

        cleaned = re.sub(r"['\"].*?['\"]", " ", prompt)
        cleaned = re.sub(
            r"\b(make|create|write|post|share|publish|upload|this|exact|text|caption|picture|image|photo|video|with|of|a|an|the)\b",
            " ",
            cleaned,
            flags=re.IGNORECASE,
        )
        return self._clean_topic(cleaned)

    def _clean_topic(self, text: str) -> Optional[str]:
        cleaned = " ".join(text.replace(":", " ").strip(" .,!?'\"").split())
        if not cleaned or cleaned.lower() in {"post", "this", "caption", "image", "picture"}:
            return None
        return cleaned[:80]

    def _extract_platform(self, lower_prompt: str) -> Optional[str]:
        for platform in self.LOCAL_PLATFORMS:
            if platform in lower_prompt:
                return self._normalize_platform(platform)
        for platform in self.REAL_PLATFORMS - {"x"}:
            if re.search(rf"\b{re.escape(platform)}\b", lower_prompt):
                return self._normalize_platform(platform)
        if re.search(r"\bx\b", lower_prompt):
            return "x"
        return None

    def _normalize_platform(self, value: str) -> str:
        lower = value.lower().strip()
        if lower in {"x", "twitter"}:
            return "x"
        if lower in self.LOCAL_PLATFORMS:
            return "local_demo"
        for platform in self.REAL_PLATFORMS:
            if platform in lower:
                return "x" if platform == "twitter" else platform
        return lower.replace(" ", "_") or "local_demo"

    def _extract_existing_media_path(self, state: PostState, prompt: str) -> None:
        if state.media_path:
            state.has_media_file = Path(state.media_path).exists()
            return
        match = re.search(r"([^\s'\"]+\.(?:jpg|jpeg|png|mp4))", prompt, flags=re.IGNORECASE)
        if match:
            media_path = Path(match.group(1)).expanduser()
            state.media_path = str(media_path)
            state.has_media_file = media_path.exists()
            state.media_type = "video" if media_path.suffix.lower() == ".mp4" else "image"

    def _is_empty_post_request(self, lower: str, state: PostState) -> bool:
        simple = lower.strip(" .!?")
        return simple in {"post this", "share this", "upload this", "post"} and not any(
            [state.caption, state.topic, state.media_prompt, state.has_media_file]
        )

    def _is_caption_only_request(self, lower: str) -> bool:
        if "caption only" in lower or "only caption" in lower:
            return True
        return lower.startswith("write a caption") or lower.startswith("create a caption")

    def _needs_upload(self, lower: str) -> bool:
        if "do not upload" in lower or "draft only" in lower or "no upload" in lower:
            return False
        if any(word in lower for word in self.UPLOAD_WORDS):
            return True
        return lower.startswith("post ") or "make a post" in lower or "create a post" in lower

    def _needs_media(self, lower: str, needs_upload: bool, caption_only: bool, state: PostState) -> bool:
        if caption_only or "text only" in lower or "no image" in lower or "without image" in lower:
            return False
        if state.has_media_file:
            return False
        if any(word in lower for word in self.MEDIA_WORDS):
            return True
        return needs_upload and not caption_only

    def _needs_research(self, prompt: str, state: PostState) -> bool:
        lower = prompt.lower()
        if state.caption or "#" in prompt:
            return False
        if "trend" in lower or "viral" in lower or "popular hashtag" in lower:
            return True
        return len(prompt.split()) < 10
