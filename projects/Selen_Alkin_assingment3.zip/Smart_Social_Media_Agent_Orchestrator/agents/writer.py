from __future__ import annotations

import json
from typing import Optional

from models import PostState
from providers import NvidiaBuildClient, NvidiaBuildError


class ContentWriterAgent:
    """Creates a caption and a media prompt without overwriting provided captions."""

    def __init__(self, llm_client: Optional[NvidiaBuildClient] = None, *, strict_api: bool = False) -> None:
        self.llm_client = llm_client
        self.strict_api = strict_api

    def write_content(self, state: PostState) -> PostState:
        if self.llm_client:
            generated = self._try_nvidia_writer(state)
            if generated:
                state.add_log("writer", "success", "Caption and media prompt generated with NVIDIA Build.")
                return state

        topic = state.topic or "your update"
        hashtags = state.hashtags[:4] or [f"#{_hashtag(topic)}", "#socialmedia"]

        if not state.caption:
            state.caption = (
                f"Bring more intention into your day with {topic}.\n\n"
                "Small consistent steps create real momentum.\n\n"
                f"{' '.join(hashtags)}"
            )

        if not state.media_prompt and state.routing_plan.get("media_creator", False):
            style = state.visual_style or "clean, modern, social-media-ready"
            state.media_prompt = (
                f"{style} image for a social media post about {topic}; "
                "high quality composition, no text overlay"
            )

        state.add_log("writer", "success", "Caption and media prompt generated with local rules.")
        return state

    def _try_nvidia_writer(self, state: PostState) -> bool:
        if not self.llm_client:
            return False

        try:
            data = self.llm_client.chat_json(
                [
                    {
                        "role": "user",
                        "content": json.dumps(
                            {
                                "task": "Generate social media caption and media prompt.",
                                "topic": state.topic,
                                "existing_caption": state.caption,
                                "keywords": state.keywords,
                                "hashtags": state.hashtags,
                                "visual_style": state.visual_style,
                                "reference_image": {
                                    "path": state.reference_image_path,
                                    "note": state.reference_image_note,
                                    "use_as_style_reference_only": bool(state.reference_image_path)
                                    and not state.use_reference_as_final_media,
                                },
                                "routing_plan": state.routing_plan,
                                "rules": [
                                    "Do not overwrite existing_caption if it is present.",
                                    "Caption must be under 2200 characters.",
                                    "Use no more than 8 hashtags.",
                                    "Return media_prompt if media_creator is true.",
                                    "If a reference_image note exists, incorporate its style/composition in the media_prompt as text guidance.",
                                ],
                                "schema": {"caption": "string", "media_prompt": "string"},
                            }
                        ),
                    }
                ],
                temperature=0.4,
            )
        except (NvidiaBuildError, ValueError, TypeError) as exc:
            state.add_log("writer", "error" if self.strict_api else "warning", f"NVIDIA NIM writer failed: {exc}")
            if self.strict_api:
                raise
            return False

        if not state.caption:
            state.caption = str(data.get("caption", "")).strip() or None
        if state.routing_plan.get("media_creator", False) and not state.media_prompt:
            state.media_prompt = str(data.get("media_prompt", "")).strip() or None
            if state.reference_image_note and state.media_prompt:
                state.media_prompt = f"{state.media_prompt}. Reference guidance: {state.reference_image_note}"

        return bool(state.caption and (state.media_prompt or not state.routing_plan.get("media_creator", False)))


def _hashtag(text: str) -> str:
    return "".join(part.capitalize() for part in text.split())[:40] or "Post"
