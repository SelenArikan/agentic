from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from config import NVIDIA_QA_FALLBACK_TO_RULES
from models import PostState
from providers import NvidiaBuildClient


class QAAgent:
    BANNED_WORDS = {"hate", "violence", "illegal"}

    def __init__(self, llm_client: Optional[NvidiaBuildClient] = None, *, strict_api: bool = False) -> None:
        self.llm_client = llm_client
        self.strict_api = strict_api

    def review(self, state: PostState) -> PostState:
        if self.llm_client:
            return self._review_with_nvidia(state)
        return self._review_with_rules(state)

    def _review_with_nvidia(self, state: PostState) -> PostState:
        media_exists = bool(state.media_path and Path(state.media_path).exists())
        try:
            data = self.llm_client.chat_json(
                [
                    {
                        "role": "user",
                        "content": json.dumps(
                            {
                                "task": "Quality assurance review for a social media post.",
                                "caption": state.caption,
                                "topic": state.topic,
                                "media_prompt": state.media_prompt,
                                "media_path_exists": media_exists,
                                "needs_media": state.routing_plan.get("media_creator", False) or state.has_media_file,
                                "reference_image_path": state.reference_image_path,
                                "rules": [
                                    "Approve only if caption is non-empty, safe, under 2200 characters, and aligned with the topic.",
                                    "Reject if media is required but the media path does not exist.",
                                    "Reject unsafe, hateful, violent, illegal, or brand-risky content.",
                                ],
                                "schema": {"status": "approved|rejected", "feedback": "string"},
                            }
                        ),
                    }
                ],
                temperature=0.1,
            )
            status = str(data.get("status", "")).strip().lower()
            feedback = str(data.get("feedback", "")).strip() or "NVIDIA NIM QA completed."
            if status not in {"approved", "rejected"}:
                raise ValueError(f"Invalid QA status: {status}")
            if (state.routing_plan.get("media_creator", False) or state.has_media_file) and not media_exists:
                status = "rejected"
                feedback = f"{feedback} Media file is required but missing."
            state.qa_status = status
            state.qa_feedback = feedback
            state.add_log("qa", status, f"NVIDIA NIM QA: {feedback}")
            return state
        except Exception as exc:
            state.add_log("qa", "error", f"NVIDIA NIM QA failed: {exc}")
            if self.strict_api and not NVIDIA_QA_FALLBACK_TO_RULES:
                raise
            state.add_log("qa", "fallback", "Using local QA rules because NVIDIA QA is unavailable.")
            return self._review_with_rules(state)

    def _review_with_rules(self, state: PostState) -> PostState:
        feedback = []

        if not state.caption or not state.caption.strip():
            feedback.append("Caption is empty.")
        elif len(state.caption) > 2200:
            feedback.append("Caption is too long for a standard social media post.")

        lower_caption = (state.caption or "").lower()
        banned = sorted(word for word in self.BANNED_WORDS if word in lower_caption)
        if banned:
            feedback.append(f"Caption contains banned words: {', '.join(banned)}.")

        if state.routing_plan.get("media_creator", False) or state.has_media_file:
            if not state.media_path:
                feedback.append("Media file is required but missing.")
            elif not Path(state.media_path).exists():
                feedback.append(f"Media file does not exist: {state.media_path}")

        if state.routing_plan.get("media_creator", False) and state.media_prompt and state.topic:
            if state.topic.lower().split()[0] not in state.media_prompt.lower():
                feedback.append("Media prompt does not clearly match the topic.")

        if feedback:
            state.qa_status = "rejected"
            state.qa_feedback = " ".join(feedback)
            state.add_log("qa", "rejected", state.qa_feedback)
        else:
            state.qa_status = "approved"
            state.qa_feedback = "Caption and media are ready for demo upload."
            state.add_log("qa", "approved", state.qa_feedback)

        return state
