from __future__ import annotations

import base64
import json
import textwrap
from pathlib import Path
from typing import Optional

from config import NVIDIA_IMAGE_FALLBACK_TO_PILLOW
from models import PostState
from providers import NvidiaBuildClient


class MediaCreatorAgent:
    """Creates a local placeholder image for the MVP."""

    FALLBACK_JPEG = (
        "/9j/4AAQSkZJRgABAQAASABIAAD/4QBMRXhpZgAATU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAAaADAAQAAAABAAAAAQAAAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/8AAEQgAAQABAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAgICAgICAwICAwUDAwMFBgUFBQUGCAYGBgYGCAoICAgICAgKCgoKCgoKCgwMDAwMDA4ODg4ODw8PDw8PDw8PD//bAEMBAgICBAQEBwQEBxALCQsQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEP/dAAQAAf/aAAwDAQACEQMRAD8A/fyiiigD/9k="
    )

    def __init__(self, nvidia_client: Optional[NvidiaBuildClient] = None, *, strict_api: bool = False) -> None:
        self.nvidia_client = nvidia_client
        self.strict_api = strict_api

    def create_media(self, state: PostState, output_dir: Path) -> PostState:
        output_dir.mkdir(parents=True, exist_ok=True)
        media_path = output_dir / "generated_post.jpg"

        if self.nvidia_client:
            try:
                response = self.nvidia_client.generate_image(
                    state.media_prompt or state.topic or state.user_prompt,
                    media_path,
                )
                (output_dir / "generated_post.nvidia_response.json").write_text(
                    json.dumps(response, indent=2),
                    encoding="utf-8",
                )
                self._write_prompt_metadata(state, output_dir, provider="nvidia-nim")
                state.media_path = str(media_path)
                state.media_type = "image"
                state.has_media_file = media_path.exists()
                state.add_log("media_creator", "success", f"Image generated with NVIDIA NIM and saved to {media_path}.")
                return state
            except Exception as exc:
                state.add_log("media_creator", "error", f"NVIDIA image generation failed: {exc}")
                if not NVIDIA_IMAGE_FALLBACK_TO_PILLOW:
                    raise

        try:
            self._create_with_pillow(state, media_path)
        except Exception as exc:
            if self.strict_api:
                raise
            media_path.write_bytes(base64.b64decode(self.FALLBACK_JPEG))
            state.add_log("media_creator", "warning", f"Pillow generation failed; used fallback JPEG: {exc}")

        self._write_prompt_metadata(state, output_dir, provider="pillow")

        state.media_path = str(media_path)
        state.media_type = "image"
        state.has_media_file = media_path.exists()
        state.add_log("media_creator", "success", f"Placeholder image saved to {media_path}.")
        return state

    def _write_prompt_metadata(self, state: PostState, output_dir: Path, *, provider: str) -> None:
        prompt_path = output_dir / "generated_post.prompt.json"
        prompt_path.write_text(
            json.dumps(
                {
                    "media_prompt": state.media_prompt,
                    "topic": state.topic,
                    "provider": provider,
                },
                indent=2,
            ),
            encoding="utf-8",
        )

    def _create_with_pillow(self, state: PostState, media_path: Path) -> None:
        from PIL import Image, ImageDraw, ImageFont

        width, height = 1080, 1080
        image = Image.new("RGB", (width, height), color=(244, 239, 229))
        draw = ImageDraw.Draw(image)

        title = (state.topic or "Social Post").title()
        subtitle = state.media_prompt or "Generated social media placeholder"
        hashtags = " ".join(state.hashtags[:4])

        try:
            title_font = ImageFont.truetype("Arial.ttf", 72)
            body_font = ImageFont.truetype("Arial.ttf", 34)
        except OSError:
            title_font = ImageFont.load_default()
            body_font = ImageFont.load_default()

        draw.rectangle([(80, 80), (1000, 1000)], outline=(35, 66, 54), width=6)
        draw.rectangle([(120, 120), (960, 360)], fill=(35, 66, 54))
        draw.text((160, 190), title[:28], fill=(255, 255, 255), font=title_font)

        y = 430
        for line in textwrap.wrap(subtitle, width=42)[:7]:
            draw.text((150, y), line, fill=(40, 40, 40), font=body_font)
            y += 52

        if hashtags:
            draw.text((150, 890), hashtags, fill=(35, 66, 54), font=body_font)

        image.save(media_path, "JPEG", quality=92)
